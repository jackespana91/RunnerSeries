# Runnerz — art finishing source pack

This is a production handoff, not an upgraded game or completed Magnific output.
18 original input images are copied unchanged, with individual enhancement briefs.
The five city covers and two runner references establish identity and style.

## Start with Buenos Aires

1. Read CITY-ART-FINISH.md. Inventory the user's additional Higgsfield originals
   before commissioning missing city artwork; that account library is uninspected.
2. Start with inputs/buenosaires/tango.webp and its job in jobs.json. Review the
   source and the actual game view together. The source is a reference for the
   finished animated 3D couple; it must not replace the obstacle with a flat image.
3. In an authenticated Magnific session, enhance selected images conservatively.
   jobs.csv contains the exact prompts. A 2x output is the proposed first pass,
   not evidence that a job has been submitted. Preserve transparency and aspect.
4. Keep results under outputs/ as candidates. Compare faces, hands, text, wheel
   geometry, transparent edges and crop against the originals before integration.
5. Create textured model/material assets and authored dance animation. Complete
   the Buenos Aires street scene with useful lighting and actual-game-camera review.
6. Use the agreed quality level for each city's four deliveries in the brief.

## Game integration

- Environment/wall art maps onto solid surfaces. Do not stretch menu covers into
  murals, or shrink all enhanced hero art into the same small atlas slot.
- Model-reference images guide silhouette, materials and animation. Magnific
  does not provide a game-ready mesh, UV layout, rig or motion clip.
- The current source is in Runnerz-Polished-Source.zip on the preview branch.
- Source images, runner identity, obstacle rules and payouts must be preserved.
- No extra Higgsfield library artwork or Magnific output is included in this pack.

## Connection status

The Magnific server is registered in the cloud Codex CLI. No Magnific tool is
exposed to this chat, and an unauthenticated direct MCP request returned HTTP401.
This does not diagnose the user's browser login or a saved OAuth token. The next
enhancement operation needs Magnific tools available to the active Codex session.
Never include cookies, tokens or OAuth callback URLs in this source pack.
